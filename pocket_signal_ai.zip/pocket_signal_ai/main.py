import os
import logging
from datetime import datetime, timezone

import pandas as pd
import requests
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

load_dotenv()
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TWELVEDATA_API_KEY = os.getenv("TWELVEDATA_API_KEY", "").strip()
TWELVEDATA_URL = "https://api.twelvedata.com/time_series"

PAIRS = {
    "EUR/USD": "EUR/USD",
    "GBP/USD": "GBP/USD",
    "USD/JPY": "USD/JPY",
    "AUD/USD": "AUD/USD",
    "USD/CAD": "USD/CAD",
    "USD/CHF": "USD/CHF",
    "NZD/USD": "NZD/USD",
}

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("pocket-signal-ai")


def fetch_candles(symbol: str) -> pd.DataFrame:
    if not TWELVEDATA_API_KEY:
        raise RuntimeError("Не задан TWELVEDATA_API_KEY в файле .env")
    response = requests.get(
        TWELVEDATA_URL,
        params={
            "symbol": symbol,
            "interval": "1min",
            "outputsize": 120,
            "apikey": TWELVEDATA_API_KEY,
            "format": "JSON",
        },
        timeout=20,
    )
    response.raise_for_status()
    payload = response.json()
    if "values" not in payload:
        message = payload.get("message") or payload.get("code") or str(payload)
        raise RuntimeError(f"Источник котировок не вернул свечи: {message}")

    df = pd.DataFrame(payload["values"])
    for col in ("open", "high", "low", "close"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["datetime"] = pd.to_datetime(df["datetime"], errors="coerce")
    df = df.dropna(subset=["datetime", "open", "high", "low", "close"])
    df = df.sort_values("datetime").reset_index(drop=True)
    if len(df) < 60:
        raise RuntimeError(f"Недостаточно свечей для анализа: {len(df)}")
    return df


def ema(series: pd.Series, period: int) -> pd.Series:
    return series.ewm(span=period, adjust=False).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = gain / loss.replace(0, pd.NA)
    return 100 - (100 / (1 + rs))


def analyze(df: pd.DataFrame):
    close = df["close"]
    e9 = ema(close, 9)
    e21 = ema(close, 21)
    e50 = ema(close, 50)
    r = rsi(close)
    macd_line = ema(close, 12) - ema(close, 26)
    macd_signal = ema(macd_line, 9)

    # Exclude the currently forming candle when possible.
    row = len(df) - 2
    if row < 50:
        row = len(df) - 1

    score_up = 0
    score_down = 0
    reasons_up, reasons_down = [], []

    if e9.iloc[row] > e21.iloc[row]:
        score_up += 1
        reasons_up.append("EMA 9 выше EMA 21")
    elif e9.iloc[row] < e21.iloc[row]:
        score_down += 1
        reasons_down.append("EMA 9 ниже EMA 21")

    if close.iloc[row] > e50.iloc[row]:
        score_up += 1
        reasons_up.append("цена выше EMA 50")
    elif close.iloc[row] < e50.iloc[row]:
        score_down += 1
        reasons_down.append("цена ниже EMA 50")

    if macd_line.iloc[row] > macd_signal.iloc[row]:
        score_up += 1
        reasons_up.append("MACD выше сигнальной линии")
    elif macd_line.iloc[row] < macd_signal.iloc[row]:
        score_down += 1
        reasons_down.append("MACD ниже сигнальной линии")

    rv = r.iloc[row]
    if pd.notna(rv):
        if 50 <= rv <= 68:
            score_up += 1
            reasons_up.append(f"RSI {rv:.1f}: умеренный бычий импульс")
        elif 32 <= rv < 50:
            score_down += 1
            reasons_down.append(f"RSI {rv:.1f}: умеренный медвежий импульс")

    # Simple candle momentum check.
    if close.iloc[row] > df["open"].iloc[row]:
        score_up += 1
        reasons_up.append("последняя закрытая свеча бычья")
    elif close.iloc[row] < df["open"].iloc[row]:
        score_down += 1
        reasons_down.append("последняя закрытая свеча медвежья")

    total = max(score_up, score_down)
    if score_up >= 4 and score_up >= score_down + 2:
        direction = "CALL ⬆️"
        score = score_up
        reasons = reasons_up
    elif score_down >= 4 and score_down >= score_up + 2:
        direction = "PUT ⬇️"
        score = score_down
        reasons = reasons_down
    else:
        direction = "НЕТ СИГНАЛА"
        score = total
        reasons = ["Подтверждений недостаточно или индикаторы противоречат друг другу."]

    candle_time = df["datetime"].iloc[row]
    return direction, score, reasons, float(close.iloc[row]), float(rv) if pd.notna(rv) else None, candle_time


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 Pocket Signal AI запущен.\n\n"
        "Команды:\n"
        "/signal EUR/USD — анализ пары\n"
        "/pairs — список пар\n\n"
        "Сигналы информационные, не гарантия прибыли. "
        "Экспирация 1 минута особенно чувствительна к задержкам и качеству котировок."
    )


async def pairs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Доступные пары:\n" + "\n".join(f"• {p}" for p in PAIRS))


async def signal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    raw = " ".join(context.args).strip().upper().replace(" ", "")
    if not raw:
        await update.message.reply_text("Укажи пару: /signal EUR/USD")
        return
    symbol = PAIRS.get(raw)
    if not symbol:
        await update.message.reply_text("Пара не найдена. Используй /pairs")
        return

    await update.message.reply_text(f"⏳ Анализирую {symbol} по минутным свечам...")
    try:
        df = fetch_candles(symbol)
        direction, score, reasons, price, rv, candle_time = analyze(df)
        confidence = round(score / 5 * 100)
        reason_text = "\n".join(f"• {item}" for item in reasons)
        rsi_text = f"{rv:.1f}" if rv is not None else "нет данных"
        await update.message.reply_text(
            f"📊 POCKET SIGNAL AI\n"
            f"Пара: {symbol}\n"
            f"Направление: {direction}\n"
            f"Экспирация: 1 минута (ориентир)\n"
            f"Оценка совпадения индикаторов: {score}/5\n"
            f"RSI: {rsi_text}\n"
            f"Последняя цена: {price}\n"
            f"Свеча: {candle_time}\n\n"
            f"Основания:\n{reason_text}\n\n"
            f"⚠️ Оценка индикаторов не является вероятностью выигрыша. "
            f"Проверь котировку на самой платформе; не открывай сделку только по этому сообщению."
        )
    except Exception as exc:
        log.exception("Signal error")
        await update.message.reply_text(f"Не удалось получить анализ: {exc}")


def main():
    if not BOT_TOKEN:
        raise SystemExit("Не задан TELEGRAM_BOT_TOKEN в файле .env")
    if not TWELVEDATA_API_KEY:
        raise SystemExit("Не задан TWELVEDATA_API_KEY в файле .env")

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("pairs", pairs))
    app.add_handler(CommandHandler("signal", signal))
    log.info("Pocket Signal AI started")
    app.run_polling()


if __name__ == "__main__":
    main()
